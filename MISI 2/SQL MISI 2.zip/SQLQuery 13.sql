DECLARE @StartDate DATE = '2021-01-01';
DECLARE @EndDate DATE   = '2025-12-31';

;WITH Dates AS (
    SELECT @StartDate AS dt
    UNION ALL
    SELECT DATEADD(DAY,1,dt)
    FROM Dates
    WHERE dt < @EndDate
)
INSERT INTO dbo.Dim_Tanggal (
    Tanggal_SK, FullDate, DayNumberOfWeek, DayName,
    MonthName, MonthNumber, Quarter, QuarterName,
    Tahun, IsWeekend, Semester
)
SELECT
    CONVERT(INT, FORMAT(dt,'yyyyMMdd')),
    dt,
    DATEPART(WEEKDAY, dt),
    DATENAME(WEEKDAY, dt),
    DATENAME(MONTH, dt),
    DATEPART(MONTH, dt),
    DATEPART(QUARTER, dt),
    'Q' + CAST(DATEPART(QUARTER, dt) AS VARCHAR(1)),
    DATEPART(YEAR, dt),
    CASE WHEN DATENAME(WEEKDAY, dt) IN ('Saturday','Sunday') THEN 1 ELSE 0 END,
    CASE WHEN DATEPART(MONTH, dt) BETWEEN 1 AND 6 THEN 'Genap' ELSE 'Ganjil' END
FROM Dates
OPTION (MAXRECURSION 0);

;WITH nums AS (
    SELECT TOP (10000)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
    FROM sys.objects a CROSS JOIN sys.objects b
)
INSERT INTO dbo.Dim_Mahasiswa (
    NIM, Nama_Mahasiswa, Fakultas, Program_Studi,
    Tahun_Masuk, Status_Mahasiswa, EffectiveDate, IsCurrent
)
SELECT
    '21' + RIGHT('00000' + CAST(n AS VARCHAR(5)), 5),
    'Mahasiswa ' + CAST(n AS VARCHAR(10)),
    CASE ABS(CHECKSUM(NEWID())) % 5
        WHEN 0 THEN 'FST'
        WHEN 1 THEN 'FS'
        WHEN 2 THEN 'FTI'
        WHEN 3 THEN 'FTSP'
        WHEN 4 THEN 'FH'
    END,
    CASE ABS(CHECKSUM(NEWID())) % 5
        WHEN 0 THEN 'Sains Data'
        WHEN 1 THEN 'Teknik Informatika'
        WHEN 2 THEN 'Teknik Sipil'
        WHEN 3 THEN 'Matematika'
        WHEN 4 THEN 'Teknik Elektro'
    END,
    2019 + (n % 5),
    'Aktif',
    GETDATE(),
    1
FROM nums;


;WITH nums AS (
    SELECT TOP (1000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
    FROM sys.objects
)
INSERT INTO dbo.Dim_Kegiatan (
    ID_Kegiatan_NK, Nama_Kegiatan, Jenis_Kegiatan, Skala_Kegiatan, Status_Kegiatan
)
SELECT
    'KG' + RIGHT('0000'+CAST(n AS VARCHAR(4)),4),
    'Kegiatan ' + CAST(n AS VARCHAR(4)),
    CASE ABS(CHECKSUM(NEWID())) % 3
        WHEN 0 THEN 'Seminar'
        WHEN 1 THEN 'Lomba'
        WHEN 2 THEN 'Baksos'
    END,
    CASE ABS(CHECKSUM(NEWID())) % 3
        WHEN 0 THEN 'Internal'
        WHEN 1 THEN 'Nasional'
        WHEN 2 THEN 'Internasional'
    END,
    CASE ABS(CHECKSUM(NEWID())) % 2
        WHEN 0 THEN 'Terlaksana'
        WHEN 1 THEN 'Batal'
    END
FROM nums;


;WITH nums AS (
    SELECT TOP (200) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
)
INSERT INTO dbo.Dim_Organisasi (
    ID_Organisasi_NK, Nama_Organisasi, Jenis_Organisasi,
    Status_Organisasi, EffectiveDate, IsCurrent
)
SELECT
    'ORG' + RIGHT('000'+CAST(n AS VARCHAR(3)),3),
    'Organisasi ' + CAST(n AS VARCHAR(3)),
    CASE ABS(CHECKSUM(NEWID())) % 2 WHEN 0 THEN 'UKM' ELSE 'Ormawa' END,
    CASE ABS(CHECKSUM(NEWID())) % 2 WHEN 0 THEN 'Aktif' ELSE 'Non-aktif' END,
    GETDATE(),
    1
FROM nums;


;WITH nums AS (
    SELECT TOP (500) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
)
INSERT INTO dbo.Dim_Prestasi (
    ID_Prestasi_NK, Nama_Penghargaan, Level_Prestasi, Kategori_Prestasi
)
SELECT
    'PR' + RIGHT('000'+CAST(n AS VARCHAR(3)),3),
    'Prestasi ' + CAST(n AS VARCHAR(3)),
    CASE ABS(CHECKSUM(NEWID())) % 3
        WHEN 0 THEN 'Regional'
        WHEN 1 THEN 'Nasional'
        WHEN 2 THEN 'Internasional'
    END,
    CASE ABS(CHECKSUM(NEWID())) % 2
        WHEN 0 THEN 'Akademik'
        WHEN 1 THEN 'Non-akademik'
    END
FROM nums;


;WITH nums AS (
    SELECT TOP (300) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
)
INSERT INTO dbo.Dim_Beasiswa (
    ID_Beasiswa_NK, Nama_Beasiswa, Sumber_Dana, Periode_Berlaku
)
SELECT
    'BS' + RIGHT('000'+CAST(n AS VARCHAR(3)),3),
    'Beasiswa ' + CAST(n AS VARCHAR(3)),
    CASE ABS(CHECKSUM(NEWID())) % 2 WHEN 0 THEN 'Internal' ELSE 'Eksternal' END,
    '202' + CAST((n % 4)+1 AS VARCHAR(1))
FROM nums;


;WITH nums AS (
    SELECT TOP (100000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
)
INSERT INTO dbo.Fact_Partisipasi_Kegiatan (
    Tanggal_SK, Mahasiswa_SK, Kegiatan_SK, Organisasi_SK,
    Jumlah_Partisipan, Partisipasi_ID, SourceSystem
)
SELECT
    (SELECT TOP 1 Tanggal_SK FROM dbo.Dim_Tanggal ORDER BY NEWID()),
    ABS(CHECKSUM(NEWID())) % 10000 + 1,
    ABS(CHECKSUM(NEWID())) % 1000 + 1,
    ABS(CHECKSUM(NEWID())) % 200 + 1,
    1,
    'P' + CAST(n AS VARCHAR(10)),
    'Generate'
FROM nums;


;WITH nums AS (
    SELECT TOP (50000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
)
INSERT INTO dbo.Fact_Dana_Kegiatan (
    Tanggal_SK, Kegiatan_SK, Organisasi_SK,
    Jumlah_Pengajuan, Jumlah_Realisasi, Transaksi_ID, SourceSystem
)
SELECT
    (SELECT TOP 1 Tanggal_SK FROM dbo.Dim_Tanggal ORDER BY NEWID()),
    ABS(CHECKSUM(NEWID())) % 1000 + 1,
    ABS(CHECKSUM(NEWID())) % 200 + 1,
    ABS(CHECKSUM(NEWID())) % 5000000 / 1.0,
    ABS(CHECKSUM(NEWID())) % 5000000 / 1.0,
    'T' + CAST(n AS VARCHAR(10)),
    'Generate'
FROM nums;
