USE [master];
GO
-- Perintah ini akan disimpan sebagai Job Step di SQL Server Agent
BACKUP LOG [DM_Kemahasiswaan_DW] 
TO DISK = N'D:\SQLBackup\Log\DM_Kemahasiswaan_DW_LOG_$(ESCAPE_S(DATE))_$(ESCAPE_S(TIME)).trn' 
WITH 
    COMPRESSION,
    NOFORMAT, 
    NOINIT, 
    NAME = N'DM_Kemahasiswaan_DW Log Backup', 
    SKIP, 
    NOREWIND, 
    NOUNLOAD, 
    STATS = 10;
GO
