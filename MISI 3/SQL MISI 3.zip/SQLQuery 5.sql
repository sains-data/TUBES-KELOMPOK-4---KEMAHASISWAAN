USE DM_Kemahasiswaan_DW;
GO

-- View untuk Analisis Keterlibatan Mahasiswa dalam Kegiatan dan Organisasi
CREATE OR ALTER VIEW [vw_Keterlibatan_Mahasiswa_Analisis]
AS
SELECT
    -- Dimensi Mahasiswa (M)
    M.NIM,
    M.Nama_Mahasiswa,
    M.Fakultas,
    M.Program_Studi,
    M.Tahun_Masuk AS Angkatan,

    -- Data Partisipasi Kegiatan (FPK, DK, DT)
    DT.Tahun AS Tahun_Kegiatan,
    DT.FullDate AS Tanggal_Kegiatan,
    DK.Nama_Kegiatan,
    DK.Jenis_Kegiatan,
    DK.Skala_Kegiatan,
    FPK.Jumlah_Partisipan,

    -- Data Organisasi (DO)
    DO.Nama_Organisasi,
    DO.Jenis_Organisasi,
    DO.Status_Organisasi

FROM
    dbo.Dim_Mahasiswa M

-- LEFT JOIN ke Fact Partisipasi Kegiatan
-- Kita akan menggunakan Fact_Partisipasi_Kegiatan (tanpa Partisi)
LEFT JOIN dbo.Fact_Partisipasi_Kegiatan FPK 
    ON M.Mahasiswa_SK = FPK.Mahasiswa_SK

-- LEFT JOIN ke Dimensi Kegiatan
LEFT JOIN dbo.Dim_Kegiatan DK 
    ON FPK.Kegiatan_SK = DK.Kegiatan_SK

-- LEFT JOIN ke Dimensi Tanggal (untuk detail waktu kegiatan)
LEFT JOIN dbo.Dim_Tanggal DT 
    ON FPK.Tanggal_SK = DT.Tanggal_SK

-- LEFT JOIN ke Dimensi Organisasi
LEFT JOIN dbo.Dim_Organisasi DO 
    ON FPK.Organisasi_SK = DO.Organisasi_SK

-- Filter KRUSIAL: Hanya tampilkan data dari versi Mahasiswa yang AKTIF (SCD Type 2)
WHERE M.IsCurrent = 1;
GO

-- Contoh kueri untuk menguji View yang sudah dibuat:
/*
SELECT TOP 100
    NIM,
    Nama_Mahasiswa,
    Fakultas,
    Tahun_Kegiatan,
    Nama_Kegiatan,
    Nama_Organisasi,
    Jumlah_Partisipan
FROM
    vw_Keterlibatan_Mahasiswa_Analisis
WHERE
    Nama_Kegiatan IS NOT NULL
ORDER BY
    Tahun_Kegiatan DESC;
*/