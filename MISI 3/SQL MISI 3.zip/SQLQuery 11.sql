-- File: 08_Data_Quality_Checks_M3.sql
USE DM_Kemahasiswaan_DW;
GO

-- -----------------------------------------------------------
-- DQ_001: Completeness - Cek NULL Foreign Keys di Fact_Penerima_Beasiswa
-- -----------------------------------------------------------
PRINT '--- Checking DQ_001: NULL Foreign Keys in Fact_Penerima_Beasiswa ---';
SELECT
    'Fact_Penerima_Beasiswa' AS TableName,
    COUNT(*) AS NullKeyCount,
    SUM(CASE WHEN StudentKey IS NULL THEN 1 ELSE 0 END) AS NullStudentKey,
    SUM(CASE WHEN ScholarshipKey IS NULL THEN 1 ELSE 0 END) AS NullScholarshipKey,
    SUM(CASE WHEN DateKey IS NULL THEN 1 ELSE 0 END) AS NullDateKey
FROM dbo.Fact_Penerima_Beasiswa
HAVING COUNT(*) > 0;
GO

-- -----------------------------------------------------------
-- DQ_002: Consistency - Cek Orphan Records di Fact_Capaian_Prestasi
-- (Fact yang menunjuk ke Dimensi yang tidak ada)
-- -----------------------------------------------------------
PRINT '--- Checking DQ_002: Orphan Records in Fact_Capaian_Prestasi ---';
SELECT
    'Fact_Capaian_Prestasi' AS TableName,
    COUNT(f.PrestasiKey) AS OrphanRecordsCount
FROM dbo.Fact_Capaian_Prestasi f
LEFT JOIN dbo.Dim_Student s ON f.StudentKey = s.StudentKey
LEFT JOIN dbo.Dim_Achievement a ON f.AchievementKey = a.AchievementKey
WHERE s.StudentKey IS NULL OR a.AchievementKey IS NULL;
GO

-- -----------------------------------------------------------
-- DQ_004: Consistency - Cek Fact yang Terhubung ke Record SCD Type 2 Lama
-- (Mengecek apakah ada data Prestasi yang masuk ke record Dim_Student lama)
-- -----------------------------------------------------------
PRINT '--- Checking DQ_004: Fact Linked to Inactive SCD Records ---';
SELECT
    'Fact_Capaian_Prestasi' AS TableName,
    COUNT(f.PrestasiKey) AS InactiveSCDLinkCount
FROM dbo.Fact_Capaian_Prestasi f
INNER JOIN dbo.Dim_Student s ON f.StudentKey = s.StudentKey
WHERE s.IsCurrent = 0;
GO

-- -----------------------------------------------------------
-- DQ_005: Duplikasi - Cek Duplikasi di Fact_Penerima_Beasiswa
-- (Asumsi: Unik berdasarkan ID Source)
-- -----------------------------------------------------------
PRINT '--- Checking DQ_005: Duplicate Records in Fact_Penerima_Beasiswa ---';
SELECT
    SourceScholarshipID, -- Asumsi kolom Natural Key dari Source
    COUNT(*) AS DuplicateCount
FROM dbo.Fact_Penerima_Beasiswa
GROUP BY SourceScholarshipID
HAVING COUNT(*) > 1;
GO
