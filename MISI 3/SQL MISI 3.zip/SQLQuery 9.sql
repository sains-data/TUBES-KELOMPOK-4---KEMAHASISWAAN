USE [master];
GO

BACKUP DATABASE [DM_Kemahasiswaan_DW]
TO DISK = N'D:\SQLBackup\Full\DM_Kemahasiswaan_DW_FULL_$(ESCAPE_SDAQ:DATE).bak' -- DIUBAH!
WITH
    COMPRESSION,
    NOFORMAT,
    NOINIT,
    NAME = N'DM_Kemahasiswaan_DW Full Backup',
    SKIP,
    NOREWIND,
    NOUNLOAD,
    STATS = 10;
GO