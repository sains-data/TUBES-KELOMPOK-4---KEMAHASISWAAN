USE [master];
GO

-- 1. Membuat Server Audit
-- CATATAN: Path di bawah harus diganti ke lokasi fisik yang aman di server produksi
CREATE SERVER AUDIT [Audit_DW_Security]
TO FILE 
(    
    FILEPATH = N'D:\SQLAudit\DW_Security\' -- Ganti dengan path di server produksi
    ,MAXSIZE = 10 MB 
    ,MAX_ROLLOVER_FILES = 5
)
WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE);
GO
-- Mengaktifkan Server Audit
ALTER SERVER AUDIT [Audit_DW_Security] WITH (STATE = ON);
GO

USE [DM_Kemahasiswaan_DW];
GO

-- 2. Membuat Database Audit Specification
-- Merekam setiap upaya SELECT pada Dim_Mahasiswa yang dilakukan oleh 'User_Rektor'
CREATE DATABASE AUDIT SPECIFICATION [Audit_Sensitive_Data_Access]
FOR SERVER AUDIT [Audit_DW_Security]
ADD (SELECT ON OBJECT::dbo.Dim_Mahasiswa BY [User_Rektor]) 
WITH (STATE = ON);
GO
