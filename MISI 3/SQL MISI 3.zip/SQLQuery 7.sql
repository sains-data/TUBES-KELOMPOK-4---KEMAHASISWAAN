USE DM_Kemahasiswaan_DW;
GO

-- Masking Nomor Telepon: Menampilkan 3 digit pertama, menyamarkan sisanya dengan 'xxxx'
ALTER TABLE dbo.Dim_Mahasiswa
ALTER COLUMN No_Telepon ADD MASKED WITH (FUNCTION = 'partial(3,"xxxx",0)');
GO

-- Masking Email: Menggunakan fungsi email bawaan (e.g., a***@m***.com)
ALTER TABLE dbo.Dim_Mahasiswa
ALTER COLUMN Email ADD MASKED WITH (FUNCTION = 'email()');
GO
