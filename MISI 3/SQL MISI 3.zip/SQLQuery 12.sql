-- File: 07_ETL_Simulasi_SCD_M3.sql
USE DM_Mahasiswa_DW;
GO

-- Asumsi: Dim_Program sudah terisi, Dim_Student awal kosong.

-- Step 1: Insert data Mahasiswa Awal di Staging
INSERT INTO stg.Student (NIM, StudentName, EnrollmentDate, ProgramCode, Status)
VALUES ('123450001', 'Budi Santoso', '2022-09-01', 'IF', 'Aktif');
GO

-- Step 2: Jalankan Load Dimensi (Initial Load)
-- Asumsi usp_Load_Dim_Student sudah ada dan berfungsi.
EXEC dbo.usp_Load_Dim_Student;
GO

-- Cek Hasil Awal (Mahasiswa A harus IsCurrent = 1)
SELECT StudentKey, NIM, StudentName, Status, IsCurrent, EffectiveDate, ExpiryDate
FROM dbo.Dim_Student WHERE NIM = '123450001';
GO

-- -----------------------------------------------------------
-- ETL_002: Skenario Perubahan (SCD Type 2 Trigger)
-- Perubahan Status: 'Aktif' -> 'Lulus'
-- -----------------------------------------------------------

-- Step 3: Update data Mahasiswa A di Staging (perubahan status)
UPDATE stg.Student SET Status = 'Lulus' WHERE NIM = '123450001';
GO

-- Step 4: Jalankan Load Dimensi (Perubahan)
EXEC dbo.usp_Load_Dim_Student;
GO

-- Cek Hasil Akhir (Verifikasi ETL_002)
-- Hasil yang diharapkan: Dua record untuk Mahasiswa A.
-- Record lama: IsCurrent=0, ExpiryDate terisi.
-- Record baru: Status='Lulus', IsCurrent=1, ExpiryDate=NULL.
SELECT StudentKey, NIM, StudentName, Status, IsCurrent, EffectiveDate, ExpiryDate
FROM dbo.Dim_Student WHERE NIM = '123450001' ORDER BY StudentKey DESC;
GO
