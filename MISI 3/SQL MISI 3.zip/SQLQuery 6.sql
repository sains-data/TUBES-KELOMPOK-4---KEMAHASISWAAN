USE DM_Kemahasiswaan_DW;
GO

-- 1. Membuat Login & User untuk Viewer BI (Contoh: Rektor/Stakeholder)
CREATE LOGIN [User_Rektor] WITH PASSWORD=N'ViewerStrongPassword!', DEFAULT_DATABASE=[DM_Kemahasiswaan_DW];
CREATE USER [User_Rektor] FOR LOGIN [User_Rektor];
-- Hanya diberikan hak db_datareader (SELECT pada tabel dan view)
ALTER ROLE [db_datareader] ADD MEMBER [User_Rektor];
GO

-- 2. Membuat Login & User untuk Admin ETL (Akses Staging & Fact)
CREATE LOGIN [User_AdminETL] WITH PASSWORD=N'ETLStrongPassword!', DEFAULT_DATABASE=[DM_Kemahasiswaan_DW];
CREATE USER [User_AdminETL] FOR LOGIN [User_AdminETL];
-- Diberikan hak Read/Write (untuk mengisi tabel Staging dan Fact)
ALTER ROLE [db_datawriter] ADD MEMBER [User_AdminETL];
ALTER ROLE [db_datareader] ADD MEMBER [User_AdminETL];
GO
