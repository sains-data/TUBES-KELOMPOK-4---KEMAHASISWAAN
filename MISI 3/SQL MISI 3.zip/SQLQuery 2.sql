CREATE OR ALTER PROCEDURE dbo.usp_Load_Fact_Capaian_Prestasi
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.Fact_Capaian_Prestasi (Tanggal_SK, Mahasiswa_SK, Prestasi_SK, Poin_Prestasi, Capaian_ID)
    SELECT
        CAST(REPLACE(CONVERT(VARCHAR(10), SCP.Tanggal_Capaian, 112), '-', '') AS INT) AS Tanggal_SK,
        M.Mahasiswa_SK, -- Hasil Lookup SK dari Mahasiswa AKTIF
        P.Prestasi_SK,  -- Hasil Lookup SK Prestasi
        SCP.Poin_Prestasi,
        SCP.Capaian_ID
    FROM stg.Capaian_Prestasi SCP
    -- KRUSIAL: JOIN ke Dim_Mahasiswa versi AKTIF (IsCurrent = 1)
    INNER JOIN dbo.Dim_Mahasiswa M ON SCP.NIM = M.NIM AND M.IsCurrent = 1 
    INNER JOIN dbo.Dim_Prestasi P ON SCP.ID_Prestasi_NK = P.ID_Prestasi_NK
    -- Mekanisme Anti-Duplikasi
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Fact_Capaian_Prestasi FCP WHERE FCP.Capaian_ID = SCP.Capaian_ID);
END;
GO
