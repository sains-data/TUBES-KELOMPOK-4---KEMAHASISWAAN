USE DM_Kemahasiswaan_DW;
GO
-- 1. Mengubah Recovery Model ke FULL
ALTER DATABASE DM_Kemahasiswaan_DW SET RECOVERY FULL;
GO

-- 2. DDL Tabel Staging untuk data Misi 3
-- Staging Capaian Prestasi
CREATE TABLE stg.Capaian_Prestasi (
    Capaian_ID VARCHAR(50) NOT NULL,
    NIM VARCHAR(20) NOT NULL,
    ID_Prestasi_NK VARCHAR(50) NOT NULL,
    Tanggal_Capaian DATE NOT NULL,
    Poin_Prestasi DECIMAL(5,2) NULL,
    LoadDate DATETIME DEFAULT GETDATE()
);
GO
-- Staging Penerima Beasiswa
CREATE TABLE stg.Penerima_Beasiswa (
    Penerima_ID VARCHAR(50) NOT NULL,
    NIM VARCHAR(20) NOT NULL,
    ID_Beasiswa_NK VARCHAR(50) NOT NULL,
    Tanggal_Penerimaan DATE NOT NULL,
    Nominal_Bantuan DECIMAL(12,2) NULL,
    LoadDate DATETIME DEFAULT GETDATE()
);
