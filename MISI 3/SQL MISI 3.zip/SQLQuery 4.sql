USE msdb;
GO

-- 1. Deklarasi Variabel
DECLARE @JobId BINARY(16);
DECLARE @JobName VARCHAR(100) = 'ETL_Daily_Fact_Load';
DECLARE @StepName VARCHAR(100) = 'Execute_All_Fact_SP';
DECLARE @ScheduleName VARCHAR(100) = 'Daily_Fact_Schedule';

-- 2. Membuat Job Utama
EXEC dbo.sp_add_job
    @job_name = @JobName,
    @enabled = 1,
    @description = N'Job untuk memuat semua Fact Table (Partisipasi, Dana, Prestasi, Beasiswa) secara harian.';

-- Mendapatkan Job ID
SELECT @JobId = job_id FROM dbo.sysjobs WHERE name = @JobName;

-- 3. Membuat Job Step (Memanggil semua Stored Procedure)
EXEC dbo.sp_add_jobstep
    @job_id = @JobId,
    @step_name = @StepName,
    @subsystem = N'TSQL',
    -- Perintah T-SQL untuk mengeksekusi semua SP
    @command = N'
        EXEC DM_Kemahasiswaan_DW.dbo.usp_Load_Fact_Partisipasi_Kegiatan;
        EXEC DM_Kemahasiswaan_DW.dbo.usp_Load_Fact_Dana_Kegiatan;
        EXEC DM_Kemahasiswaan_DW.dbo.usp_Load_Fact_Capaian_Prestasi;
        EXEC DM_Kemahasiswaan_DW.dbo.usp_Load_Fact_Penerima_Beasiswa;
    ',
    @database_name = N'DM_Kemahasiswaan_DW',
    @on_success_action = 1; -- Keluar dengan sukses

-- 4. Membuat Schedule (Harian pada Pukul 01:00 AM)
EXEC dbo.sp_add_schedule
    @schedule_name = @ScheduleName,
    @freq_type = 4,         -- Tipe: Harian
    @freq_interval = 1,     -- Setiap 1 hari
    @active_start_time = 010000; -- Jam mulai: 01:00:00

-- 5. Mengaitkan Schedule ke Job
EXEC dbo.sp_attach_schedule
    @job_id = @JobId,
    @schedule_name = @ScheduleName;
